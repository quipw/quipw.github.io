
public class Lab4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 1; i <= 120; i++ )
		{
			System.out.println("Pounds    Kilograms     " );
			System.out.println(i + "         " + i * 2.2 );
		}
	}
}
