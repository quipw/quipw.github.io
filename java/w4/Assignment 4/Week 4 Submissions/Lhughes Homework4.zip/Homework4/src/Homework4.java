// Author Lee Hughes
// Makes you enter a random integer then counts how many times you entered it and what the largest number was

import java.util.Scanner;
public class Homework4 {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	Scanner console = new Scanner(System.in);
int fail = 0;
	System.out.println("Enter a positive integer or 0 to terminate");
	int integer = console.nextInt();
	if(integer == 0){
	   fail = 1;
	}
	int numberoftimes = 0;
	int zerointeger = 0;
	
	while(integer > 0){
	    System.out.println("Please Enter another positive integer or 0 to terminate");
	    int integer1 = console.nextInt();
	    if(integer1>zerointeger){
		zerointeger = integer1;
		numberoftimes = 0;
	    }
	    if(integer1 == zerointeger){
		numberoftimes ++;
	    }
	    integer = integer1;
	}
	
if(fail == 0){
	System.out.println("Your largest number was " + zerointeger + ".");
	System.out.println("It appeared " + numberoftimes + " times");

    }
if(fail == 1){
    System.out.print("Sorry you did not enter any positive integers.");
}
    }
}