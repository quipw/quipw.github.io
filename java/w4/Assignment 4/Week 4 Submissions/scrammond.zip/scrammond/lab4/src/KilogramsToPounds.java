
public class KilogramsToPounds 
{

	/**
	This is a Java application which will make a table showing the conversion of kilograms to pounds from 20kg-200kg,
	 @author Sandy Crammond
	 */
	public static void main(String[] args)
	{ 
		
		System.out.printf("%10s%10s%n","Kilograms", "Pounds");
		
		double conversion = 2.2;
		
		for (int kilog = 20; kilog <= 200; kilog+= 20) 
		{
			double pounds = kilog * 2.2;
		   System.out.printf("%10d%10.2f%n", kilog, pounds);
       }
	}
}

	



/*
  Kilograms    Pounds
        20     44.00
        40     88.00
        60    132.00
        80    176.00
       100    220.00
       120    264.00
       140    308.00
       160    352.00
       180    396.00
       200    440.00

 */
