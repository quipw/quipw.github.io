import java.util.Scanner;
public class MaxInterger {

	/**
	  This is a Java application which tells the user to enter some positive integers, and then displays the max integer and how many times that integer was typed in,
	 @author Sandy Crammond
	 */
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
	
		int loop = 1;
	int Max = 0;
	int count = 0;

	System.out.println("Enter a positive integer (or 0 to terminate):");
	int first = console.nextInt();
	  if (first > 0)
	  {
		  Max = first;
		  count = 1;
	   while (loop > 0)
		{
		   
		  System.out.println("Enter a new positive integer (or 0 to terminate):");
			int input  = console.nextInt();
			
			if (input > Max)
			{
				Max = input;
				count = 1;
			}
			else if (input == Max)
			{
				count++;
			}
			if (input == 0)
			{
				loop = 0;
			}
		}
       System.out.println("The largest integer you entered was " + Max + ".");
       System.out.println("You entered " + Max +", " + count + " times.");
	}
	  else
	  {
		  System.out.println("Terminated.");
	  }
	}
}
/*
 Enter a positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
76
Enter a new positive integer (or 0 to terminate):
4
Enter a new positive integer (or 0 to terminate):
56
Enter a new positive integer (or 0 to terminate):
4
Enter a new positive integer (or 0 to terminate):
6
Enter a new positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
5
Enter a new positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
5
Enter a new positive integer (or 0 to terminate):
0
The largest integer you entered was 76.
You entered 76, 1 times.


Enter a positive integer (or 0 to terminate):
0
Terminated.


Enter a positive integer (or 0 to terminate):
6
Enter a new positive integer (or 0 to terminate):
6
Enter a new positive integer (or 0 to terminate):
6
Enter a new positive integer (or 0 to terminate):
4
Enter a new positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
0
The largest integer you entered was 6.
You entered 6, 3 times.


Enter a positive integer (or 0 to terminate):
4
Enter a new positive integer (or 0 to terminate):
7
Enter a new positive integer (or 0 to terminate):
4
Enter a new positive integer (or 0 to terminate):
8
Enter a new positive integer (or 0 to terminate):
9
Enter a new positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
3
Enter a new positive integer (or 0 to terminate):
0
The largest integer you entered was 9.
You entered 9, 1 times.

 */



