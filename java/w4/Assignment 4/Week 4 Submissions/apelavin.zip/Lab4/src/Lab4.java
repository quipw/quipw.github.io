
public class Lab4 {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	double conversion = 2.2;
	int kilos = 20;
	System.out.printf("%10s%10s%n", "Kilograms", "Pounds");

	for (int i = 1; i <= 10; i+=1)
	{
	    double lbs = (kilos * conversion);
	    System.out.printf("%10d%10.2f", kilos, lbs);
	    System.out.println();
	    kilos += 20;
	}


    }
}
/**
Kilograms    Pounds
20     44.00
40     88.00
60    132.00
80    176.00
100    220.00
120    264.00
140    308.00
160    352.00
180    396.00
200    440.00
*/