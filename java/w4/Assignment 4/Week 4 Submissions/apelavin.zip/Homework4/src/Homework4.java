import java.util.Scanner;
public class Homework4 {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	Scanner console = new Scanner(System.in);
int fail = 0;
	System.out.println("Enter a positive integer or 0 to terminate");
	int num = console.nextInt();
	if(num == 0){
	   fail = 1;
	}
	int count = 0;
	int largestnum = 0;
	
	while(num > 0){
	    System.out.println("Enter another positive integer or 0 to terminate");
	    int num1 = console.nextInt();
	    if(num1>largestnum){
		largestnum = num1;
		count = 0;
	    }
	    if(num1 == largestnum){
		count ++;
	    }
	    num = num1;
	}
	
if(fail == 0){
	System.out.println("Your largest number was " + largestnum + ".");
	System.out.println("It appeared " + count + " time(s).");

    }
if(fail == 1){
    System.out.print("You did not enter any positive integers.");
}
    }
}
/**
Enter a positive integer or 0 to terminate
1
Enter another positive integer or 0 to terminate
4
Enter another positive integer or 0 to terminate
3
Enter another positive integer or 0 to terminate
6
Enter another positive integer or 0 to terminate
6
Enter another positive integer or 0 to terminate
7
Enter another positive integer or 0 to terminate
43
Enter another positive integer or 0 to terminate

0
Your largest number was 43
It appeared 1 time(s)
*/