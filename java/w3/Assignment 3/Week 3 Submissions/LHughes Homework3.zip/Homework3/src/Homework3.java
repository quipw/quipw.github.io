import java.util.Scanner;
//Author Lee Hughes
public class Homework3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner console = new Scanner(System.in); 

		System.out.println("Enter an Integer: ");
		int integer1 = console.nextInt();

		System.out.println("Enter another Integer: ");
		int integer2 = console.nextInt();

		System.out.println("Enter one more Integer: ");
		int integer3 = console.nextInt();
		// Valid Triangles Start
		if (integer1 + integer2 > integer3){
			System.out.println("That is a valid Triangle, the perimeter is:");
			System.out.println(integer1 + integer2 + integer3);

			if (integer1 + integer3 > integer2){
				System.out.println("That is a valid Triangle, the perimeter is:");
				System.out.println(integer1 + integer2 + integer3);

				if (integer3 + integer2 > integer1){
					System.out.println("That is a valid Triangle, the perimeter is:");
					System.out.println(integer1 + integer2 + integer3);
					// Valid Triangles End


					// Invalid Triangles Start
					if (integer1 + integer2 <= integer3){
						System.out.println("Sorry that is not a valid triangle");

						if (integer1 + integer3 <= integer2){
							System.out.println("Sorry that is not a valid triangle");

							if (integer3 + integer2 <= integer1){
								System.out.println("Sorry that is not a valid triangle");
							}
						}

					}

				}

			}

		}
	}
}
