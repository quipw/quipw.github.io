import java.util.Scanner;

public class Homework3 {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner console = new Scanner(System.in);

	System.out.print("Enter the first side length.");
	double side1 = console.nextDouble();
	System.out.print("Enter the second side length.");
	double side2 = console.nextDouble();
	System.out.print("Enter the third side length.");
	double side3 = console.nextDouble();


	if((side1 + side2 > side3) && (side2 + side3 > side1) && (side1 + side3 > side2)){
	    System.out.println("The perimeter of a triangle with the lengths " + side1 + ", " + side2 + ", and " + side3 + " is: " + (side1 + side2 + side3));
	}else{
	    System.out.println(side1 + " + " + side2 + " + " + side3 + " does not make a valid triangle.");
	}
    }

}
/**
 * Enter the first side length.3
Enter the second side length.6
Enter the third side length.4
The perimeter of a triangle with the lengths 3.0, 6.0, and 4.0 is: 13.0
 */

