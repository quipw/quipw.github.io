import java.util.Scanner;



public class Lab3 {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	Scanner console = new Scanner(System.in);

	int flip = 0;

	System.out.println("Guess the outcome of the coin toss");
	System.out.println("Enter 0 for heads and 1 for tails");
	int guess = console.nextInt();
	if (guess != 1 && guess != 0){
	    System.out.println("That is not a valid input");
	}else{
	    double ran = (Math.random() * 1);
	    if(ran>0.5){
		flip = 0;
		System.out.println("The coin landed on heads!");
	    }
	    if(ran<=0.5){
		flip = 1;
		System.out.println("The coin landed on tails!");
	    }
	    if(flip == guess){
		System.out.println("You guessed right!");
	    }
	    if(flip != guess) {
		System.out.println("You guessed wrong.");
	    }
	}


    }

}
/**
 *Guess the outcome of the coin toss
Enter 0 for heads and 1 for tails
1
The coin landed on tails!
You guessed right!
*/