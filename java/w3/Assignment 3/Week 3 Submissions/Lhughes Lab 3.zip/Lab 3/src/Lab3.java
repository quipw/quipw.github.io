import java.util.Scanner;
// Author: Lee Hughes
// Program meant to do a heads or tails test

public class Lab3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner console = new Scanner(System.in); 
		double random = (Math.random()* 1);
		//System.out.println(random);
		System.out.print("Guess Heads or Tails(0 for Heads 1 for Tails): ");
		int guess = console.nextInt();

	
		
		
		if (guess != 1 && guess != 0){
			System.out.println("Please Guess Either 1 or 0");
			//Making Sure its heads or tails
		}
		if (random <= .5)
		{
			System.out.println("It landed on heads");
			random = 0;
		}

		if (random >= .5)
		{
			System.out.println("It landed on tails");
			random = 1;
		}
		// Whether you won or lost


		if (random == guess){
			System.out.println("Good Job You Won");
		}


		if (random != guess){
			System.out.println("Sorry you lost please try again");


		}

	}
}

