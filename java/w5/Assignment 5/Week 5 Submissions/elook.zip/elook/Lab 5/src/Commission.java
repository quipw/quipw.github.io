/**
 * The following program calculates the commission for a sales amount.
 * @author Ethan Look
 */
public class Commission {
    public static double computeCommission(double salesAmount)
    {
        double commission = 0;
        final double COMMISSION1 = .10;
        final double COMMISSION2 = .12;
        final double COMMISSION3 = .15;
        final double BOTTOM_TIER = 6000;
        final double TOP_TIER = 10000;
        if (salesAmount <= 0)
        {
            commission = 0;
        }
        else if (0.01 <= salesAmount && salesAmount <= 6000)
        {
            commission = salesAmount * COMMISSION1;
        }
        else if (6000.01 <= salesAmount && salesAmount <= 10000)
        {
            commission = BOTTOM_TIER * COMMISSION1 + (salesAmount - BOTTOM_TIER) * COMMISSION2;
        }
        else if (10000.01 <= salesAmount)
        {
            commission = BOTTOM_TIER * COMMISSION1 + (TOP_TIER - BOTTOM_TIER) * COMMISSION2 + (salesAmount - TOP_TIER) * COMMISSION3;
        }
        return commission;
    }

}
