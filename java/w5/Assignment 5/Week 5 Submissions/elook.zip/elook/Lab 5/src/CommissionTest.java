/**
This class tests the static method computeCommission from the Commission class
@author Ethan Look
*/
public class CommissionTest
{
    public static void main(String[] args)
    {
        //calculate and print the commission
        printCommission(-3000.00);
        printCommission(3000.00);
        printCommission(6000.00);
        printCommission(6000.01);
        printCommission(6001.00);
        printCommission(8000.00);
        printCommission(10000.00);
        printCommission(10000.01);
        printCommission(10001.00);
        printCommission(11000.00);
    }
    public static void printCommission(double salesAmount)
    {
        double commission = Commission.computeCommission(salesAmount);
        System.out.printf("\nThe commission on %.2f is %.2f", salesAmount, commission);
    }
}
/*
The commission on -3000.00 is 0.00
The commission on 3000.00 is 300.00
The commission on 6000.00 is 600.00
The commission on 6000.01 is 600.00
The commission on 6001.00 is 600.12
The commission on 8000.00 is 840.00
The commission on 10000.00 is 1080.00
The commission on 10000.01 is 1080.00
The commission on 10001.00 is 1080.15
The commission on 11000.00 is 1230.00
*/