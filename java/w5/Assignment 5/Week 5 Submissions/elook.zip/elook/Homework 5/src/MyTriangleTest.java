/**
This class tests the static method isValid from the Commission class MyTriangle and prints the area if true
@author Ethan Look
*/
public class MyTriangleTest {
    public static void main(String[] args) {
        printArea(3,4,5);
        printArea(3,4,8);
    }
    public static void printArea(double side1, double side2, double side3)
        {
            boolean answer = MyTriangle.isValid(side1, side2, side3);
            if (answer == true)
            {
                double area = MyTriangle.area(side1, side2, side3);
                System.out.println("The area of a triangle with sides of " + side1 + ", " + side2 + ", " + side3 + " is " + area);
            }
            else
            {
                System.out.println("Sorry, " + side1 + ", " + side2 + ", " + side3 + " do not form a triangle.");
            }
        }
}
/*
The area of a triangle with sides of 3.0, 4.0, 5.0 is 6.0
Sorry, 3.0, 4.0, 8.0 do not form a triangle.
*/