/**
   Determines if the three given values can form a triangle
   @param s1 the first value
   @param s2 the second value
   @param s3 the third value
   @return true if the three values can form a valid triangle else it returns false
*/
public class MyTriangle {
    public static boolean isValid(double side1, double side2, double side3)
    {
        boolean isValid = false;
        if (side1 + side2 > side3)
        {
            if (side2 + side3 > side1)
            {
                if (side1 + side3 > side2)
                {
                    isValid = true;
                }
                else
                {
                    isValid = false;
                }
            }
            else
            {
                isValid = false;
            }
        }
        else
        {
            isValid = false;
        }
        return isValid;
    }
    /**
       Gets the area of a triangle with the given sides
       @param s1 the first value
       @param s2 the second value
       @param s3 the third value
       @return the area of the triangle with the given sides 
            or zero if the values do not form a valid triangle
    */

    public static double area(double side1, double side2, double side3)
    {
        double Area = 0;
        double swag = (side1 + side2 + side3)/2;
        Area = Math.pow((swag * (swag - side1) * (swag - side2) * (swag - side3)), .5);
        return Area;
    }
}
