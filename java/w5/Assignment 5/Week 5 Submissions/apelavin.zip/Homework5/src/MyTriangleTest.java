import java.util.Scanner;

public class MyTriangleTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	Scanner scan = new Scanner(System.in);
    
	System.out.println("Enter the first side");
	double s1 = scan.nextInt();
	System.out.println("Enter the second side");
	double s2 = scan.nextInt();
	System.out.println("Enter the third side");
	double s3 = scan.nextInt();
	
    boolean valid = MyTriangle.isValid(s1,s2,s3);
	
    System.out.println("The area of that triangle is "+ MyTriangle.area(s1, s2, s3, valid));
	
    }

}
