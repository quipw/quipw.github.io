
public class MyTriangle {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub
    }
    public static boolean isValid(double s1, double s2, double s3){
	if (s1 + s2 >= s3 && s1 + s3 >= s2 && s2 + s3 >= s3){
	    return true;
	}else{
	    return false;
	}
    }

    public static double area(double s1, double s2, double s3, boolean valid){
	if(valid == true){double s = (s1+s2+s3)/2;
	double a = s * (s - s1) * (s - s2) * (s - s3);
	return Math.sqrt(a);
	}else{
	    return 0;
	}
    }
}
