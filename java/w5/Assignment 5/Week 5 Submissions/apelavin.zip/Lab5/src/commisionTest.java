
public class commisionTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

    }

    public static void getCommision(double amnt) {
	double com = 0;

	if (amnt <= 6000 && amnt > 0){
	    com = amnt * .1;
	}

	if (amnt > 6000 && amnt <= 10000){
	    double fdsa = 6000 * .1;
	    double asdf = (amnt - 6000) * 0.12;
	    com = fdsa + asdf;
	}

	if (amnt > 10000){
	    double fdsa = 6000 * .1;
	    double sdfa = 4000 * .12;
	    double asdf = (amnt - 10000) * 0.15;
	    com = fdsa + sdfa + asdf;
	}

	System.out.printf("\nThe commission on %.2f is %.2f",amnt,com);

    }
}
