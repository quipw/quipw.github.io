
public class commission {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub

	commisionTest.getCommision(-3000);
	commisionTest.getCommision(3000);
	commisionTest.getCommision(6000);
	commisionTest.getCommision(6000.01);
	commisionTest.getCommision(6001);
	commisionTest.getCommision(8000);
	commisionTest.getCommision(10000);
	commisionTest.getCommision(10000.01);
	commisionTest.getCommision(10001);
	commisionTest.getCommision(11000);
    
    }

}
/**
The commission on -3000.00 is 0.00
The commission on 3000.00 is 300.00
The commission on 6000.00 is 600.00
The commission on 6000.01 is 600.00
The commission on 6001.00 is 600.12
The commission on 8000.00 is 840.00
The commission on 10000.00 is 1080.00
The commission on 10000.01 is 1080.00
The commission on 10001.00 is 1080.15
The commission on 11000.00 is 1230.00
**/