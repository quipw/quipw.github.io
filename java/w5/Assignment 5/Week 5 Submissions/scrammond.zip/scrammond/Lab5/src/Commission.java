
public class Commission {

	/**
	  This is a Java application which calculates commission,
	 @author Sandy Crammond
	 */
	  int num1 = 4;
		int num2 = 7;
	public static double computeCommission(double salesAmount) {
		double pay = salesAmount;
		if (pay < 0)
		{
			pay = 0;
		}
		else
		{
		{
			if (salesAmount <= 6000)
			{
				pay= salesAmount * .1;
			}

			else if (salesAmount > 10000)
			{
				pay=((salesAmount - 10000) * .15) + 1080;
			}
			else
			{
				pay= ((salesAmount - 6000) * .12) + 600;
		}
		}
		}
		return pay;
}}