
public class MyTriangleTest {

	/**
	 	  This is a Java application which uses 2 methods (area and isValid) to tell the viewer if the the 3 input sides make a valid triangle, and if they do, tell the viewer the area of that triangle,
	 @author Sandy Crammond
	 */
	public static void main(String[] args) {
		
		double s1 = 0;
		double s2 = 0;
		double s3 = 0;
		boolean answer = MyTriangle.isValid(s1, s2, s3);
        if (answer == true)
		{
		double area = MyTriangle.area(s1, s2, s3);
		System.out.printf("The triangle with sides %.2f, %.2f, and %.2f, %10s %.2f%1s", s1, s2, s3, "has an area of", area, ".");
		}
		else
		{
			System.out.println("The sides " + s1 + ", " + s2 + ", and " + s3 + " do not form a valid triangle.");
		}
		
	}

}
/*
The triangle with sides 6.00, 8.00, and 10.00, has an area of 24.00.

The sides -6.0, -8.0, and -10.0 do not form a valid triangle.

The triangle with sides 1.00, 1.00, and 1.00, has an area of 0.43.

The sides 0.0, 3.0, and 5.0 do not form a valid triangle.

The sides 0.0, 0.0, and 0.0 do not form a valid triangle.
*/