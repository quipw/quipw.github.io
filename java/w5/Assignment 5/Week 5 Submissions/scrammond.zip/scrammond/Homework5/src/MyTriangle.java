
public class MyTriangle {

	/**
		  This is a Java application which has 2 methods (area and isValid) which can calculate the area of a triangle and also tell if 3 given sides can create a valid triangle,
	 @author Sandy Crammond
	 */
		public static double area(double s1, double s2, double s3)
		{
			double s = (s1+s2+s3)/2;
			double TriangleArea = Math.pow((s*(s - s1)*(s - s2)*(s - s3)), .5);
			if (TriangleArea <= 0)
			{
				TriangleArea = 0;
				return TriangleArea;
			}
			else
			{
			return TriangleArea;
			}
		}

	
	public static boolean isValid(double s1, double s2, double s3)
	{
		boolean valid = true;
		if (s1 + s2 <= s3)
		{
			valid = false;
			return valid;
		}
		else if (s1+s3 <= s2)
		{
			valid = false;
			return valid;
		}
		else if (s2 + s3 <= s1)
		{
			valid = false;
			return valid;
		}
		else
		{
			return valid;
		}
	}
}
