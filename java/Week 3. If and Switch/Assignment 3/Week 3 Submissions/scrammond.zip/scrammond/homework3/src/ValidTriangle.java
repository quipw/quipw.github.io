import java.util.Scanner;
public class ValidTriangle {

	/**
	This is a Java application that will tell the user if the triangle sides they input can create a valid triangle
	@author Sandy Crammond
	 */
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		
		System.out.print("Enter an integer:");
		int side1 = console.nextInt();
		
		System.out.print("Enter another integer:");
		int side2 = console.nextInt();
		
		System.out.print("Enter one more integer:");
		int side3 = console.nextInt();
		
		int side = side1 + side2;
		
		int	perimeter = side1 + side2 + side3;
		
		if (side < side3)
		{
			System.out.println("Sorry, " + side1 +", " + side2 +", and " + side3 +"," + " cannot form a triangle.");
		}
		else if (side == side3)
		{
			System.out.println("Sorry, " + side1 +", " + side2 +", and " + side3 +"," + " cannot form a triangle.");
		}
		else if (side > side3)
		{
		System.out.println("A triangle with sides " + side1 +", " + side2 +", and " + side3 +"," + " form a triangle with a perimeter of " + perimeter);
		}
	}

}
/*
Enter an integer:1
Enter another integer:1
Enter one more integer:2
Sorry, 1, 1, and 2, cannot form a triangle.

Enter an integer:4
Enter another integer:2
Enter one more integer:7
Sorry, 4, 2, and 7, cannot form a triangle.

Enter an integer:3
Enter another integer:7
Enter one more integer:9
A triangle with sides 3, 7, and 9, form a triangle with a perimeter of 19

Enter an integer:4
Enter another integer:8
Enter one more integer:2
A triangle with sides 4, 8, and 2, form a triangle with a perimeter of 14

Enter an integer:3
Enter another integer:4
Enter one more integer:5
A triangle with sides 3, 4, and 5, form a triangle with a perimeter of 12
*/