
import java.util.Scanner;

public class HeadsOrTails {

	/**
	 This is a Java application which will virtually flip a coin, after a player enters a guess, and tells them if they win or lose,
	 @author Sandy Crammond
	 */
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		System.out.println("Guess the result of a coin toss. What do you guess?");
		System.out.println("Enter 0 for heads and 1 for tails:");
		int input = console.nextInt();
		int guess;
		int side;
		int coin = (int)(Math.random() * 2);

		if (coin < 1)
		{
			side = 0;
	      }
	      else
	      {
	    	  side = 1;
	      }
		if (input > 1)
			
		{
			System.out.println("Sorry, that's an invalid guess.");
		}
	    else if (input < 0)
			
		{
			System.out.println("Sorry, that's an invalid guess.");
		}
		else if (input < 1)
		{
			guess = 0;
			if (side == guess)
			{
				System.out.println("You win! Great job!");
		      }
			else
		    {
				System.out.println("Sorry! You lose. Better luck next time!");
		      }
		}
		else
		{
			guess = 1;
			if (side == guess)
			{
				System.out.println("You win! Great job!");
		      }
			else
		    {
				System.out.println("Sorry! You lose. Better luck next time!");
		      }
		}
	
	}

}
/*
 Guess the result of a coin toss. What do you guess?
Enter 0 for heads and 1 for tails:
-1
Sorry, that's an invalid guess.

Guess the result of a coin toss. What do you guess?
Enter 0 for heads and 1 for tails:
2
Sorry, that's an invalid guess.

Guess the result of a coin toss. What do you guess?
Enter 0 for heads and 1 for tails:
1
Sorry! You lose. Better luck next time!

Guess the result of a coin toss. What do you guess?
Enter 0 for heads and 1 for tails:
1
You win! Great job!

Guess the result of a coin toss. What do you guess?
Enter 0 for heads and 1 for tails:
0
You win! Great job!
*/
