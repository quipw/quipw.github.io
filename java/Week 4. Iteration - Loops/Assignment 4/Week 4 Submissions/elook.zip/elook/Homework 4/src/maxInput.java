/**
 * This program reads an unspecified number of positive integers, keeps track of the maximum value entered and the number of times it is entered, and prints the results.
 * @author Ethan Look
 */
import java.util.Scanner;
public class maxInput {
    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        int max = -1;
        int count = 1;
        int response = 1;
        do{
            System.out.println("Enter a positive integer or 0 to terminate: ");
            response = scan.nextInt();
            if (max < response)
            {
                max = response;
                count = 1;
            }    
            else if (max == response)
            {
                count++;
            }
            
        }while(response != 0);
System.out.println("The largest positive integer entered was " + max + ", and it was entered " + count + " times.");
    }
}
/*
Enter a positive integer or 0 to terminate: 
4
Enter a positive integer or 0 to terminate: 
4
Enter a positive integer or 0 to terminate: 
4
Enter a positive integer or 0 to terminate: 
6
Enter a positive integer or 0 to terminate: 
3
Enter a positive integer or 0 to terminate: 
2
Enter a positive integer or 0 to terminate: 
1
Enter a positive integer or 0 to terminate: 
8
Enter a positive integer or 0 to terminate: 
5
Enter a positive integer or 0 to terminate: 
8
Enter a positive integer or 0 to terminate: 
8
Enter a positive integer or 0 to terminate: 
7
Enter a positive integer or 0 to terminate: 
0
The largest positive integer entered was 8, and it was entered 3 times.
*/