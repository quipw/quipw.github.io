/**This is a java program that tell the how many times the highest input was inputed
 * @author Sebastien Lengre
 */
import java.util.Scanner;
public class Maxinput {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner console = new Scanner (System.in);
		System.out.print("Enter a positive integer or 0 to terminate:");
		int content = console.nextInt();
		int max = 0;
		int count = 0;
		int loop = 1;

		if (content<0)
		{
			loop = 0;
			System.out.print("Sorry that is a invalid number.  ");
		}

		if (content>max)
		{
			max = content;
			count = 1;
		}
		while (loop>0)
		{
			System.out.print("Enter a new positive number or 0 to terminate:");
			int input= console.nextInt();

			if (input>max)
			{
				max=input;
				count=1;
			}
			else if (input==max)
			{
				count++;
			}
			if (input==0)
			{
				loop=0;
			}

		}

		System.out.println("The largest positive integer entered was "+max+" and it was entered "+count+" times");
		/**output=
		 * Enter a positive integer or 0 to terminate:4
           Enter a new positive number or 0 to terminate:5
           Enter a new positive number or 0 to terminate:3
           Enter a new positive number or 0 to terminate:6
           Enter a new positive number or 0 to terminate:6
           Enter a new positive number or 0 to terminate:7
           Enter a new positive number or 0 to terminate:4
           Enter a new positive number or 0 to terminate:0
           The largest positive integer entered was 7 and it was entered 1 times
		 */

	}

}
