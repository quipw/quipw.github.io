/**This is a java program to convert kilograms to pounds.
 * @author Sebastien Lengre
 */
public class Converter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double pounds = 2.2;
		System.out.println("Kilograms    Ponds");
		for (int i = 20; i <= 200; i+=20 )
		{
			System.out.println(i+ "           "+i*pounds);
		}

		/**output=
		 * Kilograms    Ponds
           20           44.0
           40           88.0
           60           132.0
           80           176.0
           100           220.00000000000003
           120           264.0
           140           308.0
           160           352.0
           180           396.00000000000006
           200           440.00000000000006
		 */


	}

}
